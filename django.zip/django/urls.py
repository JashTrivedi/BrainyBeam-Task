from django.urls import path
from .views import get_serialized_data

urlpatterns = [
    path('api/data/', get_serialized_data),
]
